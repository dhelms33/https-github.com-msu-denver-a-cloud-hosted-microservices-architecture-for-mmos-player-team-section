package edu.msudenver.characterStats;

import edu.msudenver.characterSheet.CharacterSheet;
import edu.msudenver.characterSheet.CharacterSheetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

public class CharacterStatsController {
    @Autowired
    private CharacterStatsRepository characterStatsRepository;
    //get all character stats
    @GetMapping(produces = "application/json")
    public ResponseEntity<List<CharacterStats>> getAllCharacterStats() {
        return ResponseEntity.ok(characterStatsRepository.findAll());
    }

    //get character stats by character name
    @GetMapping(value = "/{characterName}", produces = "application/json")
    public ResponseEntity<CharacterStats> getCharacterStatsByCharacterName(@PathVariable String characterName) {
        CharacterStats characterStats = characterStatsRepository.getCharacterStatsByCharacterName(characterName); //this method will probably not work
        return new ResponseEntity<>(characterStats, characterStats == null ? HttpStatus.NOT_FOUND : HttpStatus.OK);
    }

    //create a character stats
    public CharacterStats createCharacterStats(CharacterStats characterStats) {
        return characterStatsRepository.save(characterStats);
    }

    //delete a character stats
    public void deleteCharacterStats(String characterName) {
        characterStatsRepository.deleteById(characterName);
    }
    //patch a character stats
    public CharacterStats patchCharacterStats(CharacterStats characterStats) {
        return characterStatsRepository.save(characterStats);
    }

}


