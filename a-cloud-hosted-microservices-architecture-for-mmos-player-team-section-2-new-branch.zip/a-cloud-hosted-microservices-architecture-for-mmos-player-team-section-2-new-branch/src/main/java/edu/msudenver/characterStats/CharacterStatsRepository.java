package edu.msudenver.characterStats;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CharacterStatsRepository extends JpaRepository<CharacterStats, String> {
    CharacterStats getCharacterStatsByCharacterName(String characterName);
}
